HOMEWORK 1: MORPHOLOGICAL IMAGE PROCESSING


NAME:  < Aaron Taylor >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< John Fantell,Nathaniel Wheeler,TAs(don't remember names),ALAC tutors(don't remember names),stackoverflow.com,cplusplus.com >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < 20 >



EXTRA CREDIT:
Describe your implementation changes to allow alternate structuring
elements (different size/shape).  Paste in sample command lines,
sample input & output and discuss the different results.



MISC. COMMENTS TO GRADER:  
Optional, please be concise!


